"""
財政部促進民間參與公共建設資訊系統 - 已簽約案件爬蟲
目標：https://ppp.mof.gov.tw/WWW/inv_case.aspx

執行前安裝：
  pip install requests beautifulsoup4 lxml pandas

執行：
  python ppp_scraper.py
"""

import time
import datetime
import re
import json
import sys
import logging

import requests
import urllib3
from bs4 import BeautifulSoup
import pandas as pd

# 政府網站 SSL 憑證缺少 Subject Key Identifier，關閉驗證警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ─────────────────────────────────────────
# CONFIG（可自行調整）
# ─────────────────────────────────────────
BASE_URL    = "https://ppp.mof.gov.tw/WWW/inv_case.aspx"
OUTPUT_CSV  = "ppp_signed_cases.csv"
OUTPUT_JSON = "ppp_signed_cases.json"
DELAY       = 1.5    # 每次請求間隔秒數
MAX_PAGES   = None   # None = 全部；改為整數（如 2）可限制頁數，測試用
LOG_EVERY   = 100    # 每爬幾筆印一次進度（可改為 200 等）

# ─────────────────────────────────────────
# LOGGER
# ─────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("ppp_scraper.log", encoding="utf-8"),
    ],
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────
# 日期工具：滾動式三年區間（民國年格式）
# ─────────────────────────────────────────
def get_date_range():
    """
    返回 (start, end)，格式 YYY/MM/DD（民國年）
    start = 今年 - 3 年的 1/1
    end   = 今天
    """
    today = datetime.date.today()
    start = datetime.date(today.year - 3, 1, 1)

    def to_roc(d):
        return f"{d.year - 1911:03d}/{d.month:02d}/{d.day:02d}"

    return to_roc(start), to_roc(today)


# ─────────────────────────────────────────
# Session
# ─────────────────────────────────────────
def make_session():
    s = requests.Session()
    s.verify = False   # SSL fix：跳過憑證驗證
    s.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.8",
        "Referer": BASE_URL,
    })
    return s


# ─────────────────────────────────────────
# ASP.NET 隱藏欄位
# ─────────────────────────────────────────
def parse_aspnet_hidden(soup):
    fields = {}
    for inp in soup.find_all("input", {"type": "hidden"}):
        name = inp.get("name", "")
        if name.startswith("__"):
            fields[name] = inp.get("value", "")
    return fields


# ─────────────────────────────────────────
# 解析列表頁
# ─────────────────────────────────────────
def parse_list_page(soup):
    rows = []
    case_links = []

    table = None
    for t in soup.find_all("table"):
        if t.find("th"):
            table = t
            break

    if not table:
        log.warning("找不到資料表格")
        return rows, case_links

    headers = [th.get_text(strip=True) for th in table.find_all("th")]
    log.debug(f"表格標題：{headers}")

    for tr in table.find_all("tr"):
        cells = tr.find_all("td")
        if not cells:
            continue

        row = {}
        for i, cell in enumerate(cells):
            key = headers[i] if i < len(headers) else f"col_{i}"
            row[key] = cell.get_text(strip=True)

        link_tag = cells[0].find("a")
        if link_tag:
            case_links.append({
                "name":    link_tag.get_text(strip=True),
                "href":    link_tag.get("href", ""),
                "onclick": link_tag.get("onclick", ""),
            })
        else:
            case_links.append({"name": list(row.values())[0] if row else "", "href": "", "onclick": ""})

        rows.append(row)

    return rows, case_links


# ─────────────────────────────────────────
# 解析詳細頁
# ─────────────────────────────────────────
def parse_detail_page(soup, case_name=""):
    detail = {}

    for table in soup.find_all("table"):
        for tr in table.find_all("tr"):
            cells = tr.find_all(["th", "td"])
            if len(cells) >= 2:
                for i in range(0, len(cells) - 1, 2):
                    key = cells[i].get_text(strip=True).rstrip("：: ")
                    val = cells[i + 1].get_text(strip=True)
                    if key and val:
                        detail[key] = val

    for label in soup.find_all("label"):
        key = label.get_text(strip=True).rstrip("：: ")
        sib = label.find_next_sibling()
        if sib and key and key not in detail:
            detail[key] = sib.get_text(strip=True)

    for dl in soup.find_all("dl"):
        for dt, dd in zip(dl.find_all("dt"), dl.find_all("dd")):
            key = dt.get_text(strip=True).rstrip("：: ")
            if key:
                detail[key] = dd.get_text(strip=True)

    if not detail:
        detail["_raw_text"] = soup.get_text(separator="\n", strip=True)[:3000]

    log.debug(f"  詳細欄位數：{len(detail)}  案件：{case_name}")
    return detail


# ─────────────────────────────────────────
# 取得詳細頁
# ─────────────────────────────────────────
def fetch_detail(session, link_info, list_soup):
    href    = link_info.get("href", "")
    onclick = link_info.get("onclick", "")

    if href and href != "#" and not href.lower().startswith("javascript"):
        url = href if href.startswith("http") else f"https://ppp.mof.gov.tw/WWW/{href.lstrip('/')}"
        resp = session.get(url, timeout=30)
        resp.encoding = resp.apparent_encoding
        return BeautifulSoup(resp.text, "lxml")

    m = re.search(r"__doPostBack\('([^']+)','([^']*)'\)", onclick or href)
    if m:
        hidden = parse_aspnet_hidden(list_soup)
        payload = {**hidden, "__EVENTTARGET": m.group(1), "__EVENTARGUMENT": m.group(2)}
        resp = session.post(BASE_URL, data=payload, timeout=30)
        resp.encoding = resp.apparent_encoding
        return BeautifulSoup(resp.text, "lxml")

    log.warning(f"無法解析連結：{link_info}")
    return None


# ─────────────────────────────────────────
# 從頁面抓總頁數（格式：頁數：1/45）
# ─────────────────────────────────────────
def get_total_pages(soup):
    for text in soup.find_all(string=re.compile(r"頁數")):
        m = re.search(r"頁數[：:]\s*\d+\s*/\s*(\d+)", text)
        if m:
            return int(m.group(1))
    return None


# ─────────────────────────────────────────
# 下一頁 payload
# ─────────────────────────────────────────
NEXT_BTN = "ctl00$ContentPlaceHolder1$ListView1$DataPager1$ctl02$ctl00"

def get_next_page_payload(soup, search_params):
    """
    翻頁時必須同時帶上查詢條件，否則伺服器會忽略篩選、回傳全部資料。
    search_params 是 submit_search 用的查詢欄位（不含 __VIEWSTATE 等隱藏欄位）。
    """
    next_inp = soup.find("input", {"name": NEXT_BTN})
    if not next_inp:
        return None
    hidden = parse_aspnet_hidden(soup)
    return {**hidden, **search_params, NEXT_BTN: ">"}


# ─────────────────────────────────────────
# 初始查詢
# ─────────────────────────────────────────
def build_search_params(start_date, end_date):
    """
    查詢條件欄位（不含 __VIEWSTATE）。
    - 第一次查詢：加上 btnSearch
    - 翻頁時：不加 btnSearch（由 NEXT_BTN 觸發），但其他篩選欄位都要帶
    """
    return {
        "ctl00$ContentPlaceHolder1$FLAG":         "已簽約案件",
        "ctl00$ContentPlaceHolder1$SDATE":        start_date,
        "ctl00$ContentPlaceHolder1$EDATE":        end_date,
        "ctl00$ContentPlaceHolder1$CASE_NUMBER":  "",
        "ctl00$ContentPlaceHolder1$CASE_NAME":    "",
        "ctl00$ContentPlaceHolder1$SMONEY":       "",
        "ctl00$ContentPlaceHolder1$EMONEY":       "",
        "ctl00$ContentPlaceHolder1$CASE_TYPE1":   "ALL",
        "ctl00$ContentPlaceHolder1$UNIT":         "",
        "ctl00$ContentPlaceHolder1$UNIT2":        "",
        "ctl00$ContentPlaceHolder1$INFRA_TYPE1":  "",
        "ctl00$ContentPlaceHolder1$INFRA_TYPE2":  "",
    }


def submit_search(session):
    start_date, end_date = get_date_range()
    log.info(f"查詢條件：已簽約案件，登載期間 {start_date} ~ {end_date}（民國年）")

    resp = session.get(BASE_URL, timeout=30)
    resp.encoding = resp.apparent_encoding
    soup = BeautifulSoup(resp.text, "lxml")
    hidden = parse_aspnet_hidden(soup)

    search_params = build_search_params(start_date, end_date)
    # 第一次查詢才加 btnSearch，翻頁時不加
    first_payload = {**hidden, **search_params, "ctl00$ContentPlaceHolder1$btnSearch": "搜尋"}

    resp = session.post(BASE_URL, data=first_payload, timeout=30)
    resp.encoding = resp.apparent_encoding
    # search_params（不含 btnSearch）翻頁時繼續帶，確保篩選不被重置
    return BeautifulSoup(resp.text, "lxml"), search_params


# ─────────────────────────────────────────
# 主流程
# ─────────────────────────────────────────
def scrape():
    session = make_session()
    all_cases = []
    page = 1

    log.info("═" * 60)
    log.info("PPP 已簽約案件爬蟲 啟動")
    log.info("═" * 60)

    soup, search_params = submit_search(session)

    # 第一頁就抓總頁數，之後用計數器判斷停止
    total_pages = get_total_pages(soup)
    if total_pages:
        log.info(f"共 {total_pages} 頁，開始爬取...")
    else:
        log.warning("無法取得總頁數，將爬到無資料為止")

    while True:
        rows, case_links = parse_list_page(soup)

        if not rows:
            log.info("本頁無資料，爬取結束。")
            break

        log.info(f"第 {page}/{total_pages or '?'} 頁｜本頁 {len(rows)} 筆｜累計 {len(all_cases)} 筆")

        for row, link_info in zip(rows, case_links):
            case_name = link_info.get("name") or list(row.values())[0]

            detail = {}
            if link_info.get("href") or link_info.get("onclick"):
                try:
                    detail_soup = fetch_detail(session, link_info, soup)
                    if detail_soup:
                        detail = parse_detail_page(detail_soup, case_name)
                    time.sleep(DELAY)
                except Exception as e:
                    log.error(f"詳細頁失敗：{case_name} → {e}")

            merged = {**row, **{f"詳細_{k}": v for k, v in detail.items()}}
            merged["_爬取時間"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            all_cases.append(merged)

            # 每 LOG_EVERY 筆回報一次進度
            if LOG_EVERY and len(all_cases) % LOG_EVERY == 0:
                log.info(f"  ↳ 進度：已爬 {len(all_cases)} 筆...")

        # 已到最後一頁則停止
        if total_pages and page >= total_pages:
            log.info(f"已爬完全部 {total_pages} 頁。")
            break

        if MAX_PAGES and page >= MAX_PAGES:
            log.info(f"已達設定最大頁數 {MAX_PAGES}，停止。")
            break

        next_payload = get_next_page_payload(soup, search_params)
        if not next_payload:
            log.info("已爬完所有頁面。")
            break

        time.sleep(DELAY)
        resp = session.post(BASE_URL, data=next_payload, timeout=30)
        resp.encoding = resp.apparent_encoding
        soup = BeautifulSoup(resp.text, "lxml")
        page += 1

    log.info("═" * 60)
    log.info(f"完成！共 {len(all_cases)} 筆案件")

    if all_cases:
        pd.DataFrame(all_cases).to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
        log.info(f"CSV → {OUTPUT_CSV}")
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump(all_cases, f, ensure_ascii=False, indent=2)
        log.info(f"JSON → {OUTPUT_JSON}")
    else:
        log.warning("無資料，請確認查詢條件或網路連線。")

    return all_cases


if __name__ == "__main__":
    scrape()